Installation
============

- From PyPI::

      pip install sshuttle

- Clone::

      git clone https://github.com/sshuttle/sshuttle.git
      cd sshuttle
      ./setup.py install
