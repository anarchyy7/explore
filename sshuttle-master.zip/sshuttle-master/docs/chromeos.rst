Google ChromeOS
===============

Currently there is no built in support for running sshuttle directly on
Google ChromeOS/Chromebooks.

What we can really do is to create a Linux VM with Crostini.  In the default
stretch/Debian 9 VM, you can then install sshuttle as on any Linux box and
it just works, as do xterms and ssvncviewer etc.

https://www.reddit.com/r/Crostini/wiki/getstarted/crostini-setup-guide

